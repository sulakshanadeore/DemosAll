﻿using ShoppingLibrary;
using System.Collections;

internal class Program
{
  static  List<Products> plist = new List<Products>();
    public static void AddProductToList(Products p)
    { 
    plist.Add(p);
  }
    public static List<Products> ShowAllProducts()
    {
        return plist;
    }
    private static void Main(string[] args)
    {
        //WorkingWithList();













        //ProductOperations op=new ProductOperations();
        //op.AddProductData(p1);
        //Console.WriteLine("=====================");
        //// op.PrintStack(); //if void
        //Stack<Products> proddata=op.SendProductData();//if retur type is Stack<Products>
        //foreach (var item in proddata)
        //{
        //    Console.WriteLine(item.Prodid);
        //    Console.WriteLine(item.Prodname);
        //    Console.WriteLine(item.Price);
        //}



        //    StackOfProducts();


        //Queue<Products> q=new Queue<Products>();
        //q.Enqueue(new Products {Prodid=10,Prodname="Watch",Price=10000 });








    }

    private static void WorkingWithList()
    {
        char userchoice = 'N';
        do
        {
            Products p1 = new Products();
            Console.WriteLine("Enter productid");
            p1.Prodid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter product name");
            p1.Prodname = Console.ReadLine();
            Console.WriteLine("Enter product price");
            p1.Price = Convert.ToInt32(Console.ReadLine());
            //plist.Add(p1);
            Program.AddProductToList(p1);
            List<Products> updatedList = Program.ShowAllProducts();
            //  Console.WriteLine(updatedList);

            foreach (var item in updatedList)
            {
                Console.WriteLine(item.Prodid);
                Console.WriteLine(item.Prodname);
                Console.WriteLine(item.Price);
            }
            Console.WriteLine("Do u want to continue? Y/N");
            userchoice = Convert.ToChar(Console.ReadLine());
        } while (userchoice == 'Y' || userchoice == 'y');
    }
    //static void StackOfProducts()
    //{
    //    Stack<int> s1 = new Stack<int>();
    //    s1.Push(3);

    //    Stack<Products> prodStack = new Stack<Products>();

    //    Products p1 = new Products();
    //    p1.Prodid = 1;
    //    p1.Prodname = "Tea";
    //    p1.Price = 10;

    //    prodStack.Push(p1);
    //    //Object initializer
    //    Products p2 = new Products { Prodid = 2, Prodname = "Coffee", Price = 20 };
    //    prodStack.Push(p2);

    //    //Collection Initializer

    //    prodStack.Push(new Products { Prodid = 3, Prodname = "Bournvita", Price = 30 });

    //    foreach (var item in prodStack)
    //    {
    //        Console.WriteLine(item.Prodid);
    //        Console.WriteLine(item.Prodname);
    //        Console.WriteLine(item.Price);
    //        Console.WriteLine("--------------");
    //    }


    //    Products foundOrNot = prodStack.Where(p => p.Prodid == 1).Single();
    //    if (foundOrNot != null)
    //    {
    //        Console.WriteLine("following details are found.");

    //        Console.WriteLine(foundOrNot.Prodid);
    //        Console.WriteLine(foundOrNot.Prodname);
    //        Console.WriteLine(foundOrNot.Price);
    //        Console.WriteLine("Now chnaging to following");

    //        foundOrNot.Prodname = "Green Tea";
    //        foundOrNot.Price = 15;

    //        Console.WriteLine(foundOrNot.Prodid);
    //        Console.WriteLine(foundOrNot.Prodname);
    //        Console.WriteLine(foundOrNot.Price);

    //    }
    //    else
    //    {
    //        Console.WriteLine("Not found");
    //    }




    //}
}