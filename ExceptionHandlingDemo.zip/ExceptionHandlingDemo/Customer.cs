﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    [Serializable]
    internal class Customer
    {
        int id;
        public int Custid { get { return id; } set { id = value; } }
        public string CustName { get; set; }

        public string City { get; set; }

        public long FromAccount { get; set; }

        public long ToAccount { get; set; }

        public decimal Amt { get; set; }
        public DateTime TxnDate { get; set; }

    }
}
