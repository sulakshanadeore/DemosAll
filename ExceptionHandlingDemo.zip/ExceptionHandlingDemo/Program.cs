﻿using ExceptionHandlingDemo;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;
using System.Text.Json;
using System.Data;

internal class Program
{
    static List<Customer> custlist = new List<Customer>()
   {
    new Customer{Custid=1,CustName="Arpita",City="Pune",Amt=10000},
        new Customer{Custid=2,CustName="Alpana",City="Mumbai" },
            new Customer{Custid=3,CustName="Akshata",City="Bangalore" }

    };
    public static void Main(string[] args)
    {
        //Customer c = new Customer {Custid=11,FromAccount=1,ToAccount=2,Amt=20000,TxnDate=DateTime.Now };

        ////Serialize
        //FileStream fs=new FileStream("custDataInJson.json",FileMode.Create,FileAccess.Write);   
        //StreamWriter sw=new StreamWriter(fs);
        //string jsondata = JsonSerializer.Serialize(c);
        //sw.Write(jsondata);
        //sw.Flush();
        //sw.Close();
        //fs.Close();
        //fs.Dispose();



        FileStream fs = new FileStream("custDataInJson.json", FileMode.Open, FileAccess.Read);
        StreamReader sr = new StreamReader(fs);
       string data = sr.ReadToEnd();

        Console.WriteLine(data);
        sr.Close();
        sr.Dispose();
        fs.Close();
        fs.Dispose();










        //  SimpleTryCatch();

        //create a static list


        //WorkingWithTryCatchFinally();

        //SerializationDeSerializationBinary();


    }

    private static void SerializationDeSerializationBinary()
    {
        FileStream fs = new FileStream("custData.bin", FileMode.Open, FileAccess.Read);
        BinaryFormatter bf = new BinaryFormatter();
        Customer data = (Customer)bf.Deserialize(fs);
        Console.WriteLine(data.Custid);
        Console.WriteLine(data.CustName);
        Console.WriteLine(data.City);
        Console.WriteLine(data.FromAccount);
        Console.WriteLine(data.ToAccount);
        Console.WriteLine(data.Amt);
        Console.WriteLine(data.TxnDate);


        //Writing to file

        //Customer c = new Customer();
        //Console.WriteLine("Enter custid");
        //c.Custid = Convert.ToInt32(Console.ReadLine());
        //Console.WriteLine("Enter from accoutn");
        //c.FromAccount = Convert.ToInt64(Console.ReadLine());
        //Console.WriteLine("Enter to account");
        //c.ToAccount = Convert.ToInt64(Console.ReadLine());
        //Console.WriteLine("Enter Date");
        //c.TxnDate = Convert.ToDateTime(Console.ReadLine());
        //Console.WriteLine("Enter Amt");
        //c.Amt = Convert.ToDecimal(Console.ReadLine());  
        //FileStream fs = new FileStream("custData.bin", FileMode.Create, FileAccess.Write);
        //BinaryFormatter bf = new BinaryFormatter();
        //bf.Serialize(fs, c);

        //fs.Close();
        //fs.Dispose();
    }

    private static void WorkingWithTryCatchFinally()
    {
        custlist.Add(new Customer { Custid = 4, CustName = "Barkha", City = "Pune" });




        try
        {


            Console.WriteLine("enter custid to find");
            int input = Convert.ToInt32(Console.ReadLine());

            Customer c = custlist.Find(p => p.Custid == input);
            if (c == null)
            {
                throw new CustomerNotFoundException("custid not found in db...");
            }
            else
            {
                Console.WriteLine(c.Custid);
                Console.WriteLine(c.CustName);
                Console.WriteLine(c.City);
            }
        }
        catch (CustomerNotFoundException ex)
        {
            //FileStream fs=File.Create("errorMessage.txt");
            //fs.Close();
            //fs.Dispose();
            //fs=File.OpenWrite("errorMessage.txt");
            //StreamWriter sw=new StreamWriter(fs);
            //sw.Write(ex.Message);
            //sw.Flush();

            //sw.Close();
            //sw.Dispose();
            //fs.Close();
            //fs.Dispose();

            FileStream fs = new FileStream("errorMessage.txt", FileMode.Create, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(ex.Message);
            sw.WriteLine(DateTime.Now.ToLongTimeString());
            sw.Flush();
            sw.Close();
            sw.Dispose();
            fs.Close();
            fs.Dispose();

            Console.WriteLine(ex.Message);
            Console.WriteLine(ex.StackTrace);
        }
        finally
        {
            Console.WriteLine("This block executes compulsory, even if there is a exception or not");
            Console.WriteLine("Finally is used to close connection and release the resources/free up the memory+");

        }
    }

    private static void SimpleTryCatch()
    {
        Console.WriteLine("Enter a number");
        int no = 0, ans = 0;
        try
        {
            no = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second number");
            int no2 = Convert.ToInt32(Console.ReadLine());
            if (no2 == 0)
            {
                throw new DivideByZeroException();
            }
            else
            {
                ans = no / no2;
                Console.WriteLine(ans);
            }
        }
        catch (FormatException ex)
        {

            Console.WriteLine(ex.Message);

        }
        catch (OverflowException ex)
        {
            Console.WriteLine("Number not in range of integer");

        }
        catch (DivideByZeroException ex)
        {
            Console.WriteLine("Denominator cannot be 0");
            Console.WriteLine(ex.Message);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);

        }
    }
}