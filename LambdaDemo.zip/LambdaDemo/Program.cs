﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
List<int> l1=new List<int>();
l1.Add(1);
l1.Add(2);
l1.Add(3);
l1.Add(4);  
l1.Add(5);
l1.Add(6);
l1.Add(7);  
l1.Add(8);
l1.Add(9);
l1.Add(10);

int ans=l1.Find(i=>i%2==0);
Console.WriteLine(ans);

List<int> evenNos=l1.FindAll(i => i % 2 == 0);
foreach (int i in evenNos)
{
    Console.WriteLine(i);
}
    
