﻿// See https://aka.ms/new-console-template for more information
using ShoppingLibraryDisconnected;

Console.WriteLine("Hello, World!");

//CustomerUtility utility=new CustomerUtility();
////Customer c = new Customer();
////c.FirstName = "Gaurang";
////c.LastName = "T";
////c.City = "Mumbai";
////c.Mobile = "9876543212";
////bool status=utility.AddCustomer(c);
////Console.WriteLine(status);

//utility.RemoveCustomer(1);


IndigoAirlinesDataSet 
