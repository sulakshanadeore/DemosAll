﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsContd_SortedSetSortedList
{
    internal class Customer : IComparable
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public DateTime RegDate { get; set; }


        public int CompareTo(object other)
        {
            Customer c = (Customer)other;
            return this.Name.CompareTo(c.Name);
        }

        //public int CompareTo(object other)
        //{
        //    Customer c= (Customer)other;
        //    return this.Age.CompareTo(c.Age);
        //}
    }



    internal class Person:IComparable
    {
        public string Name { get; set; }
        public int Age { get; set; }

        public int CompareTo(object obj)
        {
            Person p = (Person)obj;
         
            return this.Age.CompareTo(p.Age);
        }
    }
}
