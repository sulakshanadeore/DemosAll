﻿
using CollectionsContd_SortedSetSortedList;

internal class Program
{
    private static void Main(string[] args)
    {
        //SimpleSortedSet();

        //SortedListDemo();

        //  IComparableWithArray();

        List<Customer> custlist = new List<Customer>();
        custlist.Add(new Customer { Name = "Jack", Age = 10, RegDate = new DateTime(2020, 2, 2) });
        custlist.Add(new Customer { Name = "Smith", Age = 20, RegDate = new DateTime(2021, 1, 13) });
        custlist.Add(new Customer { Name = "Geeta", Age = 1, RegDate = new DateTime(2023, 11, 3) });
        custlist.Add(new Customer { Name = "Sita", Age = 23, RegDate = new DateTime(2021, 1, 31) });
        custlist.Add(new Customer { Name = "Kat", Age = 33, RegDate = new DateTime(2019, 5, 3) });

        custlist.Sort();
        custlist.Reverse();
        foreach (var item in custlist)
        {
            Console.WriteLine(item.Name);
            Console.WriteLine(item.Age);
            Console.WriteLine(item.RegDate);
            Console.WriteLine("----------");
        }






    }

    private static void IComparableWithArray()
    {
        Person[] people = new Person[3];
        people[0] = new Person();
        people[0].Name = "Abhishek";
        people[0].Age = 10;

        people[1] = new Person();
        people[1].Name = "Arti";
        people[1].Age = 21;

        people[2] = new Person();
        people[2].Name = "Hari";
        people[2].Age = 1;



        Array.Sort(people);
        foreach (var item in people)
        {
            Console.WriteLine(item.Name);
            Console.WriteLine(item.Age);
            Console.WriteLine("----------");
        }
    }

    private static void SortedListDemo()
    {
        SortedList<int, int> data = new SortedList<int, int>();
        data.Add(7, 8);
        data.Add(1, 2);
        data.Add(31, 4);
        data.Add(14, 5);
        data.Add(5, 6);
        data.Add(36, 7);
        data.Add(8, 9);

        foreach (KeyValuePair<int, int> item in data)
        {
            Console.WriteLine(item.Key + " " + item.Value);


        }
    }

    private static void SimpleSortedSet()
    {
        SortedSet<int> set = new SortedSet<int>();
        set.Add(110);
        set.Add(1);
        set.Add(87);
        set.Add(23);



        foreach (var item in set)
        {
            Console.WriteLine(item);
        }
    }
}