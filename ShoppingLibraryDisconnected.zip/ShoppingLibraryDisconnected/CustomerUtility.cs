﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingLibraryDisconnected
{
    public class CustomerUtility
    {
        CustomerDAL dal=new CustomerDAL();

        public bool AddCustomer(Customer c)
        {
            bool status=dal.InsertCustomer(c);
            return status;
        }
        public bool RemoveCustomer(int custid)
        {
bool status=dal.DeleteCustomer(custid);
            return status;


        }

        public bool EditCustomer(int id, Customer newdetails)
        {
            bool status=dal.UpdateCustomer(id, newdetails);
            return status;  
        }

        public List<Customer> GetCustomerList()
        {
List<Customer> customers= dal.CustomerList();
            return customers;
        }

        public Customer FindCustomer(int id) {
        return dal.SelectCustomer(id); 
        }



    }
}
