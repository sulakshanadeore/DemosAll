﻿
namespace ShoppingLibraryDisconnected
{
    [Serializable]
    internal class InvalidMobileNumberException : Exception
    {
        public InvalidMobileNumberException()
        {
        }

        public InvalidMobileNumberException(string? message) : base(message)
        {
        }

        public InvalidMobileNumberException(string? message, Exception? innerException) : base(message, innerException)
        {
        }
    }
}