﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Microsoft.Data.SqlClient;
namespace ShoppingLibraryDisconnected
{
    internal class CustomerDAL
    {
        public bool InsertCustomer(Customer c)
        {
            SqlConnection cn = new SqlConnection("server=.\\sqlexpress;database=IndigoAirlines;Integrated Security=true;Trust Server Certificate=true");
            SqlDataAdapter da = new SqlDataAdapter("select * from Customer", cn);
            DataSet ds = new DataSet();

            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            da.Fill(ds, "Customer");//existing data, if any, is filled in the
                                    //in-memory cache(DataSet), u get disconnected from database server

            //newrow is the empty/blank row
            DataRow newrow=ds.Tables["Customer"].NewRow();
            
            //filled the data
            newrow["Custid"] = c.Custid;
            newrow["FirstName"] = c.FirstName;
            newrow["LastName"]=c.LastName;
            newrow["City"] = c.City;
            newrow["Mobile"] = c.Mobile;

            //add it to the existing row collection
            ds.Tables["Customer"].Rows.Add(newrow);

            SqlCommandBuilder bldr=new SqlCommandBuilder(da);
            int cnt=da.Update(ds.Tables["Customer"]);
            bool txnStatus = false;
            if (cnt > 0)
            { 
            txnStatus = true;   
            }

            return txnStatus;





        }
        public bool DeleteCustomer(int custid) 
        {

            SqlDataAdapter da = null;
            DataSet ds = null;
       DataRow drow =ConnectAndFillDataInDataSet(custid);
                bool txnStatus = false;
            if (drow != null)
            {
                 drow.Delete();
                //Update database server
                SqlCommandBuilder bldr = new SqlCommandBuilder(da);
               int cnt=da.Update(ds.Tables["Customer"]);
                if (cnt > 0) 
                { 
                  txnStatus=true;
                }
            }
            else {
                throw new CustomerNotFoundException($"{custid} Customer doesn't exists... ");
            
            }

            return txnStatus;
        }

        public bool UpdateCustomer(int id, Customer newdetails)
        {
            SqlDataAdapter da = null;
            DataSet ds = null;
            bool txnStatus = false;
            DataRow drow = ConnectAndFillDataInDataSet(id);
            if (drow != null)
            {
                drow["Custid"] = newdetails.Custid;
                drow["FirstName"]=newdetails.FirstName;
                drow["LastName"] = newdetails.LastName;
                drow["City"] = newdetails.City;
                drow["Mobile"] = newdetails.Mobile;
                SqlCommandBuilder bldr = new SqlCommandBuilder(da);
                int cnt = da.Update(ds.Tables["Customer"]);
                if (cnt > 0)
                {
                    txnStatus = true;
                }
            }
            else
            {
                throw new CustomerNotFoundException($"{id} Customer doesn't exists... ");
              }
            return txnStatus;
        }

        private static DataRow ConnectAndFillDataInDataSet(int id)
        {
            SqlConnection cn = new SqlConnection("server=.\\sqlexpress;database=IndigoAirlines;Integrated Security=true;Trust Server Certificate=true");
            SqlDataAdapter da = new SqlDataAdapter("select * from Customer", cn);
            DataSet ds = new DataSet();

            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            da.Fill(ds, "Customer");//existing data, if any, is filled in the
                                    //in-memory cache(DataSet), u get disconnected from database server

            DataRow drow = ds.Tables["Customer"].Rows.Find(id);
            bool txnStatus = false;
            return drow;
        }

        public List<Customer> CustomerList()
        {
            SqlConnection cn = new SqlConnection("server=.\\sqlexpress;database=IndigoAirlines;Integrated Security=true;Trust Server Certificate=true");
            SqlDataAdapter da = new SqlDataAdapter("select * from Customer", cn);
            DataSet ds = new DataSet();

            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            da.Fill(ds, "Customer");//existing data, if any, is filled in the
                                    //in-memory cache(DataSet), u get disconnected from database server
                List<Customer> list = new List<Customer>();
            for (int i = 0; i <= ds.Tables["Customer"].Rows.Count; i++) 
            {
            Customer c=new Customer();
                DataRow drow=ds.Tables["Customer"].Rows[i];
                c.Custid = Convert.ToInt32(drow["Custid"]);
                c.FirstName = drow["FirstName"].ToString();
                c.LastName = drow["LastName"].ToString();
                c.City = drow["City"].ToString();
                c.Mobile= drow["Mobile"].ToString();
                list.Add(c);

            }
            return list;
        }
        public Customer SelectCustomer(int id) { 
        DataRow drow=ConnectAndFillDataInDataSet(id);
            Customer c=new Customer();
            c.Custid = Convert.ToInt32(drow["Custid"]);
            c.FirstName = drow["FirstName"].ToString();
            c.LastName = drow["LastName"].ToString();
            c.City = drow["City"].ToString();
            c.Mobile = drow["Mobile"].ToString();
            return c;



        }
    }
}
