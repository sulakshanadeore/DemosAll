﻿using System.Text.RegularExpressions;

namespace ShoppingLibraryDisconnected
{
    public class Customer
    {
        public int Custid { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string City { get; set; }

        string _mobile;
        public string Mobile
        { 
            get 
            { 
                return _mobile; 
            } 
            set 
            {
                if (Regex.IsMatch(value, @"^\d{10}$")) 
                {
                    _mobile = value;

                }
                else 
                {
                    throw new InvalidMobileNumberException("Check your mobile number... Invalid...");
                
                }
            } 
        }
    }
}
