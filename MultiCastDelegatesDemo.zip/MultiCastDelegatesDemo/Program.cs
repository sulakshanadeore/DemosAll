﻿// See https://aka.ms/new-console-template for more information
using MultiCastDelegatesDemo;



StringOperations o=new StringOperations();

WorkingOnStrings[] delArray = new WorkingOnStrings[3]
{
    o.ConvertToUpper,
    o.ConvertToLower,
    o.FirstCharToUpper
};

WorkingOnStrings d=MulticastDelegate.Combine(delArray) as WorkingOnStrings;

o.InputString = "helLOworld";
d.Invoke();

Console.WriteLine("---------------------------------------------");
WorkingOnStrings d1 = MulticastDelegate.Remove(d,delArray[0]) as WorkingOnStrings;
o.InputString = "wELCOME";
d.Invoke();

Console.WriteLine("-------------------------------------");
WorkingOnStrings d3=MulticastDelegate.Combine(delArray[1], delArray[2]) as WorkingOnStrings;

WorkingOnStrings dObj=MulticastDelegate.RemoveAll(d1, d3) as WorkingOnStrings;
if (dObj == null)
    Console.WriteLine("Cannot invoke null");
//For 2 methods
//WorkingOnStrings d1 = new WorkingOnStrings(o.ConvertToUpper);
//WorkingOnStrings d2 = new WorkingOnStrings(o.ConvertToLower);

//o.InputString = "udita";
//WorkingOnStrings d3=MulticastDelegate.Combine(d1, d2) as WorkingOnStrings;
//d3.Invoke();

