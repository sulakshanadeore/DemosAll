﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiCastDelegatesDemo
{
    public delegate void WorkingOnStrings();
    internal class StringOperations
    {
        public string InputString { get; set; }
        public void ConvertToUpper()
        {
            Console.WriteLine(InputString.ToUpper());
         }
        public void ConvertToLower() 
        {
            Console.WriteLine(InputString.ToLower());
        }
        public void FirstCharToUpper()
        {
            string s = char.ToUpper(InputString[0]) + InputString.Substring(1).ToLower();
            Console.WriteLine(s);
        }

    }
}
